  <footer class="iq-footer">
        <div class="container-fluid">
            <div class="row">              
                <div class="col-lg-12 text-center">
                    <span class="mr-1">
                        © <a href="<?php echo base_url(); ?>" target="_blank" class=""><?php echo website_name; ?></a>. All Rights Reserved.
                    </span>
                </div>
            </div>
        </div>
    </footer>   

    
    <script src="<?php echo base_url(); ?>media/admin/js/backend-bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/customizer.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/sidebar.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/flex-tree.min.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/tree.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/table-treeview.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/sweetalert.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/vector-map-custom.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/chart-custom.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/charts/01.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/charts/02.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/slider.js"></script>
    <script src="<?php echo base_url(); ?>media/admin/vendor/emoji-picker-element/index.js" type="module"></script>
    <script src="<?php echo base_url(); ?>media/admin/js/app.js"></script> 
    <script src="//cdn.ckeditor.com/4.19.0/full/ckeditor.js"></script>
    <script>
        function readURL(input) 
        {
            if (input.files && input.files[0]) 
            {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $("#blah").css("display","block");
                    $('#blah').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
         $("#imgInp").change(function()
         {
            readURL(this);
        });
         // --------alll delete-------
         $(document).ready(function(){
             $(".delete").click(function(event){
                 alert("Delete?");
                 var href = $(this).attr("href")
                 var btn = this;
                  $.ajax({
                    type: "GET",
                    url: href,
                    success: function(response) 
                    {
                      if (response == "Success")
                      {
                        $(btn).closest('tr').fadeOut("slow");
                      }
                      else
                      {
                        alert("Error");
                      }
                    }
                  });
                 event.preventDefault();
              })
        });
    </script>

    <script type="text/javascript">
        inactivityTimeout = false;
        resetTimeout()
        function onUserInactivity() {
           window.location.href = "<?=base_url('admin/lockscreen') ?>";
        }
        function resetTimeout() {
           clearTimeout(inactivityTimeout)
           inactivityTimeout = setTimeout(onUserInactivity, 1000 * 6000)
        }
        window.onmousemove = resetTimeout
    </script>