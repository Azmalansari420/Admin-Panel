<?php
$user = $this->crud->selectDataByMultipleWhere('tbl_admin',array('id'=>$this->session->userdata("id"),));
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Lock Screen</title>
      <?php $this->load->view('admin/include/css'); ?>  

     </head>
  <body class=" ">
    <!-- loader Start -->
    <?php echo loder; ?> 
    <!-- loader END -->
    
      <div class="wrapper">
      <section class="login-content">
         <div class="container h-100">
            <div class="row align-items-center justify-content-center h-100">
               <div class="col-md-5">
                  <div class="card">
                     <div class="card-body">
                        <div class="row align-items-center">
                           <div class="col-lg-12">
                              <div class="auth-logo">
                                 <img src="<?php echo base_url(); ?>media/uploads/<?php echo $user[0]->image; ?>" class="img-fluid  rounded-normal  darkmode-logo" alt="logo">
                                 <img src="<?php echo base_url(); ?>media/uploads/<?php echo $user[0]->image; ?>" alt="user-icon" class="img-fluid rounded-normal light-logo">
                              </div>
                              <div class="text-center">
                                 <h2 class="mb-2">Hi ! <?php echo $user[0]->first_name; ?></h2>
                                 <p>Enter your password to access the admin.</p>
                                 <?php echo $this->session->flashdata('message',);  ?>
                              </div>
                              <form method="post" enctype="multipart/form-data" action="#">
                                 <input type="hidden" name="username" value="<?php echo $user[0]->username; ?>">
                                 <div class="row">
                                    <div class="col-lg-12">
                                       <div class="form-group">
                                          <label>Password</label>
                                          <input class="form-control" type="password" placeholder="********" name="password">
                                       </div>
                                    </div>
                                 </div>
                                 <button type="submit" name="submit" class="btn btn-primary btn-block">Login</button>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      </div>
    
  <?php $this->load->view('admin/include/footer'); ?>

  </body>
</html>