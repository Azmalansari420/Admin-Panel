<!DOCTYPE html>
<html lang="en" dir="ltr" class="sid-plesk">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Admin Panel</title>
      <link rel="stylesheet" href="<?php echo base_url(); ?>media/admin/css/plesk-ui-library.css">
      <link rel="stylesheet" href="<?php echo base_url(); ?>media/admin/css/main.css">
      <link href="<?php echo base_url(); ?>media/admin/css/global.css" media="screen" rel="stylesheet" type="text/css">
   </head>
   <body class="sid-login">
      <div id="plesk-root">
         <div class="login-page">
            <div class="pul-layout pul-layout--simplified pul-layout--sm pul-layout--header login-page__inner">
               <div class="pul-layout__inner">
                  <header class="pul-layout__header pul-layout__header--on" style="height: 64px;">
                     <div class="pul-layout__header-inner">
                        <div class="pul-layout__header-content">
                           <div class="pul-layout__header-content-inner">
                              <div class="login-page-header">
                                 <div class="login-page-header__brand"> <span class="brand"> <img class="brand__logo" src="<?php echo base_url(); ?>media/admin/images/user/admin.svg" alt="Plesk Obsidian 18.0.49" style="height: 50px;"> </span> </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </header>
                  <div class="pul-layout__container">
                     <div class="pul-layout__content">
                        <div class="pul-layout__content-addon">
                           <div class="pul-layout__content-addon-inner"></div>
                        </div>
                        <main class="pul-layout__main">
                           <div class="pul-layout__main-inner">
                              <div id="main" class="login-page__content">
                                 <form class="pul-form login-page__form" method="post" action="#">
                                    <div id="loginSection">
                                       <?php echo $this->session->flashdata('message'); ?> 
                                       <div class="pul-section-item pul-section-item--vertical pul-form-field pul-form-field-text">
                                          <div class="pul-section-item__title">
                                             <div class="pul-form-field__label"><label for="login_name">Username</label></div>
                                          </div>
                                          <div class="pul-section-item__value">
                                             <div> <span class="pul-input pul-input--size-fill pul-form-field-text__input"> <input type="text" class="pul-input__input" name="username"> </span> </div>
                                          </div>
                                       </div>
                                       <div class="pul-section-item pul-section-item--vertical pul-form-field pul-form-field-password">
                                          <div class="pul-section-item__title">
                                             <div class="pul-form-field__label"> <label for="passwd">Password</label></div>
                                          </div>
                                          <div class="pul-section-item__value">
                                             <div>
                                                <div class="pul-form-field-password__control pul-form-field-password__control--fill">
                                                   <div class="pul-form-field-password__field pul-form-field-password__field--fill"> <span class="pul-input pul-input--size-fill pul-input--affix pul-form-field-password__input"> <input type="password" class="pul-input__input" name="password" > </span> </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="g-recaptcha" data-sitekey="<?=g_captcha_site_key ?>"></div>
                                    <div class="pul-section pul-section--vertical pul-form__footer">
                                       <div class="pul-section-item pul-section-item--vertical pul-form-field">
                                          <div class="pul-section-item__value">
                                             <div> <button class="pul-button pul-button--lg pul-button--primary pul-button--fill login-page__login-button" type="submit" name="submit"> <span class="pul-button__inner"> <span>Log in</span> </span> </button> </div>
                                          </div>
                                       </div>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </main>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>

   </body>
</html>